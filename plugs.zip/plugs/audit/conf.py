from uliweb.form import *

#class ManageForm(Form):
#    debug_log = BooleanField(label='Debug Log:', key='ORM/DEBUG_LOG')
#    auto_create = BooleanField(label='Auto Create Table:', key='ORM/AUTO_CREATE')
#    connection = StringField(label='Database Connection String:', required=True, key='ORM/CONNECTION')
