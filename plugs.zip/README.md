Plugs (Uliewb app collections project)
========================================

> Limodou <limodou@gmail.com>

About Plugs
----------------

Uliweb is a Python based web framework. And Plugs is an apps collection project 
of uliweb, so you can use useful apps in your project.

This project was created by Limodou <limodou@gmail.com>.

License
------------

Plugs is released under BSD license.

