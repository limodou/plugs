# CodeMirror 2

CodeMirror 2 is a rewrite of [CodeMirror
1](http://github.com/marijnh/CodeMirror). The docs live
[here](http://codemirror.net/doc/manual.html), and the project page is
[http://codemirror.net/](http://codemirror.net/).
