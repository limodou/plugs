def call(app, var, env):
    a = []
    a.append('jqcombobox/css/sexy-combo.css')
    a.append('jqcombobox/css/sexy/sexy.css')
    a.append('jqcombobox/css/custom/custom.css')
    a.append('jqcombobox/jquery.bgiframe.min.js')
    a.append('jqcombobox/jquery.sexy-combo.js')
    return {'toplinks':a}
