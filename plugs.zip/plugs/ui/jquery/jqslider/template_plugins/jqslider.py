def call(app, var, env):
    a = []
    a.append('jqslider/jquery.slider.css')
    a.append('jqslider/jquery.slider.min.js')
    return {'toplinks':a}
