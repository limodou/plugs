def call(app, var, env):
    a = []
    a.append('colorpicker/jquery.colorPicker.min.js')
    return {'toplinks':a}
